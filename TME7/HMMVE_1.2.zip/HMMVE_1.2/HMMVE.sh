#! /bin/sh
#  

java -jar HMMVE_1.2.jar

