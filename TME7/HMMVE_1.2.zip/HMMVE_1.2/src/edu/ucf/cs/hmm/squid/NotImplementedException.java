package edu.ucf.cs.hmm.squid;

public class NotImplementedException extends RuntimeException {

}
