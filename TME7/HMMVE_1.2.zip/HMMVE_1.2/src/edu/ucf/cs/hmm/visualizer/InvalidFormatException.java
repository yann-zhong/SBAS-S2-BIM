package edu.ucf.cs.hmm.visualizer;

public class InvalidFormatException extends Exception {
	public InvalidFormatException()
	{
		super();
	}
	public InvalidFormatException(String message)
	{
		super(message);
	}

}
