package edu.ucf.cs.hmm.squid;

import java.io.IOException;

public class UnknownFormatException extends IOException {

}
