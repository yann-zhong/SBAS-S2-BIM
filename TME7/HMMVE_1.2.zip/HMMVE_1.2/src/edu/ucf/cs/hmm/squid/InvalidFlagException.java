package edu.ucf.cs.hmm.squid;

public class InvalidFlagException extends Exception {

}
