package edu.ucf.cs.hmm.squid;

public class SQParameterException extends Exception {

}
